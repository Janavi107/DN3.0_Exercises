package com.library;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.library.service.BookService;

public class LibraryManagementApplication {
    public static void main(String[] args) {
        // Load the Spring context
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");


        BookService bookService = context.getBean(BookService.class);

  
        bookService.addBooks("Spring is in the Action");

        System.out.println("Library Management Application is running with the annotation-based configuration.");
    }
}