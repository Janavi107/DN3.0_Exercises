package FactoryExample;

public interface Document {
	void open();
}
