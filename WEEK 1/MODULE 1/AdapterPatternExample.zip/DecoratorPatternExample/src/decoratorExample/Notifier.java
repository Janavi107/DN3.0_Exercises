package decoratorExample;
	public interface Notifier {
	    void send(String message);
	}
