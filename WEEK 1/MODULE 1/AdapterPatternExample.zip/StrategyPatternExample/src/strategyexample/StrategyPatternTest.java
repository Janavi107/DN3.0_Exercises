package strategyexample;
public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9876", "Preethi");
        PaymentContext paymentContext = new PaymentContext(creditCardPayment);
        paymentContext.executePayment(150.00);
        System.out.println();
        PaymentStrategy payPalPayment = new PayPalPayment("preethi@gmail.com");
        paymentContext = new PaymentContext(payPalPayment);
        paymentContext.executePayment(200.00);
    }
}
