package proxyexample;

public interface Image {
	void display();

}
