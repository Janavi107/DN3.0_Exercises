package mvc_example;
public class MVCPatternTest {
    public static void main(String[] args) {
        Student student = new Student("Rahul", "12345", "A+");
        StudentView view = new StudentView();
        StudentController controller = new StudentController(student, view);
        controller.updateView();
        controller.setStudentName("Sathish");
        controller.setStudentId("90428");
        controller.setStudentGrade("A+");
        controller.updateView();
    }
}
