package dependency_injection_example;

public interface CustomerRepository {
	Customer findCustomerById(String id);

}
