package Adapterexample;
public class AmazonPayGateway {
    public void pay(double amount) {
        System.out.println("Payment of $" + amount + " processed via Amazon Pay.");
    }
}
