package commandexample;

public interface Command {
	void execute();
}
