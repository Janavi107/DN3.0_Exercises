package com.springboot.EmployeeManagementSystem.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
@Getter
@AllArgsConstructor // to create the constructor
//creating this class to pass the value at the time of entering new record

public class EmployeeDTO {
	private String name;
	private String email;
	private double salary;
	private int deptid;
	public Object getName() {
		// TODO Auto-generated method stub
		return this.name;
	}
	public Object getEmail() {
		// TODO Auto-generated method stub
		return this.email;
	}
	public Integer getDeptid() {
		// TODO Auto-generated method stub
		return this.deptid;
	}

}