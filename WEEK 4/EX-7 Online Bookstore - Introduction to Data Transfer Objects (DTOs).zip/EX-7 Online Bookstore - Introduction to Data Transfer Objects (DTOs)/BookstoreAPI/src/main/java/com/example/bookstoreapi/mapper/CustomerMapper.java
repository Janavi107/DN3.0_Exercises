package com.example.bookstoreapi.mapper;

public class CustomerMapper {

}
