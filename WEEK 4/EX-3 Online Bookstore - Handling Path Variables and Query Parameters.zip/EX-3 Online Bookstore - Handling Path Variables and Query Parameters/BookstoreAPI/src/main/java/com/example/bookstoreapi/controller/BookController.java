package com.example.bookstoreapi.controller;

import com.example.bookstoreapi.model.Book;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/books")
public class BookController {

    @GetMapping
    public List<Book> getAllBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1L, "Spring in Action", "Craig Walls", 29.99, "1234567890"));
        books.add(new Book(2L, "Effective Java", "Joshua Bloch", 45.00, "0987654321"));
        return books;
    }

    @GetMapping("/{id}")
    public Book getBookById(@PathVariable Long id) {
        return new Book(id, "Spring Boot Up & Running", "Mark Heckler", 40.00, "1122334455");
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        book.setId(new Random().nextLong());
        return book;
    }

    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        book.setId(id);
        return book;
    }

    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable Long id) {
        return "Book with ID " + id + " has been deleted.";
    }

    @GetMapping("/search")
    public List<Book> searchBooks(@RequestParam(required = false) String title,
                                  @RequestParam(required = false) String author) {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1L, "Spring in Action", "Craig Walls", 29.99, "1234567890"));
        books.add(new Book(2L, "Effective Java", "Joshua Bloch", 45.00, "0987654321"));
        books.add(new Book(3L, "Java Concurrency in Practice", "Brian Goetz", 50.00, "1122446677"));

        if (title != null) {
            books.removeIf(book -> !book.getTitle().equalsIgnoreCase(title));
        }
        if (author != null) {
            books.removeIf(book -> !book.getAuthor().equalsIgnoreCase(author));
        }

        return books;
    }
}
